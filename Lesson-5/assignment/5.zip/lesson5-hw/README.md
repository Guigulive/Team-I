# payroll

A payroll system developed with React and Solidty for Ethereum Blockchain platform. 

## Get Started

1. Install dependencies `npm install -g truffle ethereumjs-testrpc`
1. Install [Metamask](https://metamask.io/)
1. Run `testrpc`
1. Add first account in testrpc to Metamask by importing private key
1. Run `truffle compile` in the project directory
1. `truffle migrate`
1. `npm run start`
